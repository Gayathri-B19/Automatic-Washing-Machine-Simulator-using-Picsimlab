/*
 * File:   main.c
 * Author: SRJ GAYATHRI B
 *
 * Created on 10 October, 2021, 8:14 AM
 */

#include "main.h"
#pragma config WDTE=OFF //WATCH DOG TIMER IS DISABLED (WDTE=OFF)

unsigned char operation_mode,key,reset_mode,program_no=0,water_level_index=0;
int wash_time,rinse_time,spin_time;
char *washing_prg[]={"Daily","Heavy","Delicates","Whites","Stainwash","Eco Cotton", "Wollens", "Bedsheets","Rinse+Dry","Dry Only","Wash only","Aqua Store"};
char *water_level_arr[]={"Auto","Low","Medium","High","Max"};
unsigned char sec,min;
//initialization function
static void init_config(void) 
{
    //initialize the values here
    init_clcd(); //INITIALISING CLCD MODULE (DISPLAY MODULE)
    init_digital_keypad();  //INITIALISING DIGITAL KEYPAD MODULE
    init_timer2();
    FAN_DDR=0;
    BUZZER_DDR=0;
    ADCON1=0X06;//TURN OFF ANALOG TO DIGITAL CONVERTOR
    DC_MOTOR_DDR=0;//OUTPUT
    DC_MOTOR=OFF;
    
    PEIE=1;
    GIE=1;
}

//main function
void main(void) 
{   
    //unsigned char key;
    operation_mode=WASHING_PROGRAM_DISPLAY;
    reset_mode=WASHING_PROGRAM_DISPLAY_RESET;
    
    init_config();  
    // 1st display screen==> Welcome Screen
    clcd_print("     WELCOME    ", LINE1(0));
    clcd_print("PRESS KEY5-(RB4)", LINE2(0));
    clcd_print("  TO POWER ON  ", LINE3(0));
    clcd_print("WASHING MACHINE!", LINE4(0));
    while(read_digital_keypad(STATE)!=SW5)
    {
     for(int j=3000;j--;);   //delay
    } //SW5=>0X2F
    
    clear_screen(); //clearing display screen
    
    power_on_screen(); //2nd display screen=> power on button
   
    
    while(1)
    {
      
      key=read_digital_keypad(STATE);//EDGE TRIGGER
      for(int j=3000;j--;);//delay
      
      if(key == LSW4 && operation_mode==WASHING_PROGRAM_DISPLAY)
      {
       //display water level screen 
        operation_mode=WATER_LEVEL;
        reset_mode=WATER_LEVEL_RESET;
      }
      
      else if(key == LSW4 && operation_mode==WATER_LEVEL)
      {
        //Set timings for washing program
          set_time_for_program();
          
        //display start stop screen screen
        clear_screen();
        clcd_print("  PRESS SWITCH  ", LINE1(0));
        clcd_print("KEY5-(RB4):START", LINE2(0));
        clcd_print("KEY6-(RB5):STOP", LINE3(0));
        
        operation_mode=START_STOP_SCREEN;
      }
      
    else if(key==SW5 && operation_mode==PAUSE)//RESUME MACHINE
    {
     TMR2ON=ON;//START TIMER   
     FAN=ON;
     DC_MOTOR=ON;
     operation_mode=START_PROGRAM;
    }
    
    switch(operation_mode)
      {
        case WASHING_PROGRAM_DISPLAY:
            washing_program_modes(key);
            break;
        case WATER_LEVEL:
            water_level_display(key);
            break;
        case START_STOP_SCREEN:
            if(key==SW5)
            {
                operation_mode=START_PROGRAM;
                reset_mode=START_PROGRAM_RESET;//reset is required for initialisation
                continue;
            }
            
            else if(key==SW6)
            {
                operation_mode=WASHING_PROGRAM_DISPLAY;
                reset_mode=WASHING_PROGRAM_DISPLAY_RESET;
                continue;
            }
             break;
           // else if(key==SW5)
        
        case START_PROGRAM:
            run_prg(key);
        break;
            
               
      }
      
      reset_mode=RESET_NOTHING;

    }
}
//clearing screen function
void clear_screen(void)
{
      clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
      __delay_us(100);
}

//powering on screen--> 2nd screen
void power_on_screen(void)
{
    //Printing Blocks on first line
    for(unsigned char i=0;i<16;i++)
    clcd_putch(BLOCK, LINE1(i));
    
    clcd_print("   POWERING ON  ", LINE2(0));
    clcd_print("WASHING MACHINE!", LINE3(0));
    
    //Printing Blocks on last line
    for(unsigned char i=0;i<16;i++)
    clcd_putch(BLOCK, LINE4(i));
    __delay_ms(3000);
}

//washing_program_display
void washing_program_modes(unsigned char key)
{
    if(reset_mode==WASHING_PROGRAM_DISPLAY_RESET)
    { clear_screen(); //clearing display screen
      program_no=0;
    }
    
    if(key==SW4)
    {
        program_no++;
        if(program_no==12)
         program_no=0;
        clear_screen();
    }
    
    //Display washing programs
    clcd_print("Washing Programs",LINE1(0));
    clcd_putch(ARROW,LINE2(0));
    
    if(program_no <=9)
    {
     clcd_print(washing_prg[program_no],LINE2(2));
     clcd_print(washing_prg[program_no+1],LINE3(2));
     clcd_print(washing_prg[program_no+2],LINE4(2));
    }
    
    if(program_no == 10)
    {
     clcd_print(washing_prg[program_no],LINE2(2));
     clcd_print(washing_prg[program_no+1],LINE3(2));
     clcd_print(washing_prg[0],LINE4(2));
    }
    
    if(program_no == 11)
    {
     clcd_print(washing_prg[program_no],LINE2(2));
     clcd_print(washing_prg[0],LINE3(2));
     clcd_print(washing_prg[1],LINE4(2));
   }
}


//WATER LEVEL DISPLAY
void water_level_display(unsigned char key)
{
    if(reset_mode==WATER_LEVEL_RESET)
    { 
      water_level_index=0;
      clear_screen(); //clearing display screen
    }
    
    
    if(key==SW4)
    {
        water_level_index++;
        if(water_level_index==5)
         water_level_index=0;
        clear_screen();
    }
    
    clcd_print("   Water Level  ",LINE1(0));
    clcd_putch(ARROW,LINE2(0));
    if(water_level_index<=2)
    {    
     clcd_print(water_level_arr[water_level_index],LINE2(2));
     clcd_print(water_level_arr[water_level_index+1],LINE3(2));
     clcd_print(water_level_arr[water_level_index+2],LINE4(2));
    }
    
    else if(water_level_index==3)
    {    
     clcd_print(water_level_arr[water_level_index],LINE2(2));
     clcd_print(water_level_arr[water_level_index+1],LINE3(2));
     clcd_print(water_level_arr[0],LINE4(2));
    }
    
    else if(water_level_index==4)
    {    
     clcd_print(water_level_arr[water_level_index],LINE2(2));
     clcd_print(water_level_arr[0],LINE3(2));
     clcd_print(water_level_arr[1],LINE4(2));
    }
}
void set_time_for_program(void)
{
    switch(program_no)
    {
        case 0://Daily
            switch(water_level_index)
            {
                case 1://Low
                    sec=33;
                    min=0;
                    break;
                case 0://Auto
                case 2://Medium
                    sec=41;
                    min=0;
                    break;
                case 3://High
                case 4://Very High
                    sec=45;
                    min=0;
            }
            break;
        
        case 1://Heavy
            switch(water_level_index)
            {
                case 1://Low
                    sec=43;
                    min=0;
                    break;
                case 0://Auto
                case 2://Medium
                    sec=50;
                    min=0;
                    break;
                case 3://High
                case 4://Very High
                    sec=57;
                    min=0;
            }
            break;
        
        case 2://Delicates
            switch(water_level_index)
            {
                case 1://Low
                case 0://Auto
                case 2://Medium
                    sec=26;
                    min=0;
                    break;
                case 3://High
                case 4://Very High
                    sec=31;
                    min=0;
            }
            break;

        case 3://Whites
            sec=16;
            min=1;
            break;
        
        case 4://Stainwash
            //96 sec=1 min 36 sec
            sec=36;
            min=1;
            break;

        case 5://Eco Cottons
            sec=28;
            min=0;
            break;            
            
        case 6: //Woollens
            sec=29;
            min=0;
            break;
            
        case 7://Bedsheets
            switch(water_level_index)
            {
                case 1://Low
                    sec=46;
                    min=0;
                    break;
                case 0://Auto
                case 2://Medium
                    sec=53;
                    min=0;
                    break;
                case 3://High
                case 4://Very High
                    sec=60;
                    min=0;
            }
            break;
            
        case 8: //Rinse+Dry
            switch(water_level_index)
            {
                case 1://Low
                    sec=18;
                    min=0;
                    break;
                case 0://Auto
                case 2://Medium
                case 3://High
                case 4://Very High
                    sec=20;
                    min=0;
            }
            break;
        
        case 9: //Dry Only
            sec=6;
            min=0;
            break;
        
        case 11: //Aqua Store
        case 10: //Wash only
            switch(water_level_index)
            {
                case 1://Low
                    sec=16;
                    min=0;
                    break;
                case 0://Auto
                case 2://Medium
                    sec=21;
                    min=0;
                    break;
                case 3://High
                case 4://Very High
                    sec=26;
                    min=0;
            }
            break;            
    }
}
void door_open_status(void)//RB0 IF PRESSED THEN DOOR IS OPEN
{
    if(RB0==0)//DOOR OPEN CONDITION
    {
        BUZZER=ON;
        FAN=OFF;
        DC_MOTOR=OFF;
        TMR2ON=OFF;
        clear_screen();
        clcd_print("DOOR IS OPEN!!!",LINE1(0));
        clcd_print("CLOSE DOOR!",LINE3(0));
        while(RB0==0);
        
        clear_screen();
        BUZZER=OFF;
        FAN=ON;
        DC_MOTOR=ON;
        TMR2ON=ON;
        clcd_print("FUNCTION - ",LINE1(0));
        clcd_print("TIME:",LINE2(0));
        clcd_print("5-START  6-PAUSE",LINE4(0));
    }
        
}
void run_prg(unsigned char key)
{   
    door_open_status();
    static int total_time,time;
    if(reset_mode==START_PROGRAM_RESET)
    {
        clear_screen();
        clcd_print("PRGM:",LINE1(0));
        clcd_print(washing_prg[program_no],LINE1(6));

        clcd_print("TIME:",LINE2(0));
        clcd_putch((min/10)+'0',LINE2(6));
        clcd_putch((min%10)+'0',LINE2(7));
        clcd_putch(':',LINE2(8));
        clcd_putch((sec/10)+'0',LINE2(9));
        clcd_putch((sec%10)+'0',LINE2(10));
        
        clcd_print("(MM",LINE3(5));
        clcd_putch(':',LINE3(8));
        clcd_print("SS)",LINE3(9));

        __delay_ms(2000); //2 sec delay
    
        //DISPLAY NEXT SCREEN
        clear_screen();
        clcd_print("FUNCTION - ",LINE1(0));
        clcd_print("TIME:",LINE2(0));
        clcd_print("5-START  6-PAUSE",LINE4(0));
        
        time=total_time=min*60+sec;
        wash_time=(int)(0.46*total_time);
        rinse_time=(int)(0.12*total_time);
        spin_time=(int)(0.42*total_time);
        TMR2ON=1;
        //START THE FAN
        FAN=ON;
        DC_MOTOR=ON;
    }
    
    if(key==SW6)//PAUSE MACHINE
    {
       TMR2ON=OFF;
       FAN=OFF;
       DC_MOTOR=OFF;
       operation_mode=PAUSE;
    }
   
    total_time=min*60+sec;
    
    if(program_no<=7) 
    {
      if(total_time>=time-wash_time)
        clcd_print("Wash",LINE1(11));
     else if(total_time>=time-wash_time-rinse_time)
        clcd_print("Rinse",LINE1(11));
     else
        clcd_print("Spin ",LINE1(11));  
    }    
     
    else if(program_no==8)//Rinse(40%)+Dry(60%)
    {
        if(total_time>=time-(0.4*time))
            clcd_print("Rinse",LINE1(11));
        else
            clcd_print("Spin  ",LINE1(11));
    }
    
    else if(program_no==9)//only Rinse
    {
        clcd_print("Rinse",LINE1(11));
    }
    
    else //only wash
    {
        clcd_print("Wash",LINE1(11));
    }
    
    
    clcd_putch((min/10)+'0',LINE2(6));
    clcd_putch((min%10)+'0',LINE2(7));
    clcd_putch(':',LINE2(8));
    clcd_putch((sec/10)+'0',LINE2(9));
    clcd_putch((sec%10)+'0',LINE2(10));

     if(sec==0 && min==0)
     {
       TMR2ON=OFF;//STOP THE TIMER
       FAN=OFF;//TURN OFF FAN
       DC_MOTOR=OFF;
       BUZZER=ON;//TURN ON BUZZER
       
       clear_screen();
       clcd_print("Prog. Completed",LINE1(0));
       clcd_print("Remove Clothes",LINE2(0));
       __delay_ms(2000);
       BUZZER=OFF;
       operation_mode=WASHING_PROGRAM_DISPLAY;
       reset_mode=WASHING_PROGRAM_DISPLAY_RESET;
       clear_screen();
      }
}










