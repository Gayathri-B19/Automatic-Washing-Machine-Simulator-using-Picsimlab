/*
 * File:   main.c
 * Author: SRJ GAYATHRI B
 *
 * Created on 10 October, 2021, 8:14 AM
 */
#include <xc.h>
#include "digital_keypad.h"

void init_digital_keypad(void)
{
    KEYPAD_PORT_DDR=KEYPAD_PORT_DDR | INPUT_LINES; //TRISB=TRISB | 0X3F;
}
unsigned char read_digital_keypad(unsigned char mode)
{
    static unsigned char once=1;
    static unsigned char pre_key;    //initial value=0 --> static variable
    static unsigned char longpress; //initial value=0 --> static variable
    
    if(mode==LEVEL_DETECTION)
    {
        return KEYPAD_PORT & INPUT_LINES; //PORTB & 0X3F
    }
    
    else
    {
        if(((KEYPAD_PORT & INPUT_LINES)!=ALL_RELEASED)&& once)
        {
          once =0;
          longpress=0;
          pre_key=KEYPAD_PORT & INPUT_LINES;
          //return KEYPAD_PORT & INPUT_LINES;
        }
       
        else if(!once && (pre_key==(KEYPAD_PORT & INPUT_LINES)) && longpress <30)
        {
            longpress++;
        }
        
        else if(longpress==30)
        {
            longpress++;
            //return pre_key; //cannot differentiate long_press
            return 0x80 | pre_key; //to recognize long_press ==> 0x80 | 0x37 = 0xB7
        }

        else if(((KEYPAD_PORT & INPUT_LINES)==ALL_RELEASED)&& !once)
        {
            once=1;
            if(longpress<30)
            {
                return pre_key;
            }
            
        }
        
    }
    return ALL_RELEASED;
}
