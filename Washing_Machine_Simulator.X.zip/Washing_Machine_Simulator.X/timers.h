/* 
 * File:   timers.h
 * Author: SRJ GAYATHRI B
 *
 * Created on 16 October, 2021, 1:15 PM
 */


#ifndef TIMERS_H
#define	TIMERS_H

void init_timer2(void);

#endif	/* TIMERS_H */
